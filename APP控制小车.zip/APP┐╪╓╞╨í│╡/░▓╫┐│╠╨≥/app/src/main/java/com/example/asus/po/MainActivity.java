package com.example.asus.po;

import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import java.net.Socket;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class MainActivity extends AppCompatActivity {

    String sendinfo;
    Handler handler = new myhandler();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageButton turnup = (ImageButton)findViewById(R.id.imageButton);
        ImageButton turndown = (ImageButton)findViewById(R.id.imageButton2);
        ImageButton turnlift = (ImageButton)findViewById(R.id.imageButton3);
        ImageButton turnright= (ImageButton)findViewById(R.id.imageButton4);
        ImageButton stop = (ImageButton)findViewById(R.id.imageButton5);
        ImageButton light = (ImageButton)findViewById(R.id.imageButton6);
        final TextView disinfo = (TextView)findViewById(R.id.textView);
        turnup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendinfo="4";
                disinfo.setText("前进");
                new Thread(new mythread()).start();
            }
        });
        turndown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendinfo="5";
                disinfo.setText("后退");
                new Thread(new mythread()).start();
            }
        });
        turnlift.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendinfo="l";
                disinfo.setText("左转");
                new Thread(new mythread()).start();
            }
        });
        turnright.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendinfo="r";
                disinfo.setText("右转");
                new Thread(new mythread()).start();
            }
        });
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendinfo="6";
                disinfo.setText("刹车");
                new Thread(new mythread()).start();
            }
        });
        light.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendinfo="3";
                disinfo.setText("开关灯");
                new Thread(new mythread()).start();
            }
        });
    }
    public class myhandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            String str1 = (String) msg.obj;
        }
    }

    public class mythread implements Runnable {
        String recinfo;
        @Override
        public void run() {
            try {
                Socket socket = new Socket("192.168.4.1", 9000);
                PrintWriter out = new PrintWriter(socket.getOutputStream());
                out.println(sendinfo);
                out.flush();
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                if (in.read() != 0) {
                    recinfo = in.readLine();
                } else {
                    recinfo = "error";
                }
                in.close();
                out.close();
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
                recinfo = "error";
            }
            Message message = Message.obtain();
            message.obj = recinfo;
            handler.sendMessage(message);
        }

    }
}
